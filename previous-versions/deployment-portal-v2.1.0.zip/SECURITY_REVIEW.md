# Security Review — Deployment Portal
**URL:** https://deployment-portal-instrumental.web.app/
**Date:** 2026-03-20
**Stack:** React 18 + Firebase Realtime Database + Firebase Hosting + Google OAuth

---

## 1. Authentication

| Item | Status | Notes |
|------|--------|-------|
| Google OAuth (Sign in with Google) | ✅ Enforced | All users must authenticate via Google before accessing any data |
| @instrumental.com auto-admin | ✅ Implemented | Users with this domain are automatically granted admin role on first sign-in |
| Non-instrumental users require approval | ✅ Implemented | New users land in `pendingUsers` and must be manually approved by an admin |
| Authorized domains | ✅ Configured | `deployment-portal-instrumental.web.app` added to Firebase Auth authorized domains |
| OAuth redirect URIs | ✅ Configured | `/__/auth/handler` whitelisted in Google Cloud OAuth credentials |

**Risk:** Anyone with a Google account can attempt to sign in and will land in the pending queue. An admin must actively approve or reject them. Ensure pending user notifications are monitored.

---

## 2. Authorization

| Item | Status | Notes |
|------|--------|-------|
| Firebase Database rules | ✅ Strong | Server-side rules enforce admin-only writes; deny all by default |
| `appState/docData` | ✅ Admin write only | `role === 'admin'` checked server-side in rules |
| `appState/projects` | ✅ Admin write only | Same as above |
| `users/` node | ✅ Restricted | Only the user themselves or an admin can write; requires `id, name, email, role, partyId` fields |
| `pendingUsers/` node | ✅ Admin read | Only admins can view the pending queue |
| Client-side role checks | ⚠️ Supplementary only | UI hides admin controls for non-admins, but this is enforced at the DB rules level, not just the client |

**Risk:** All authenticated users can **read** `appState/docData` and `appState/projects`. There is no per-project or per-party read restriction — any approved user can read all project data. If you need to restrict a user to only their assigned project/party's data, the database rules would need to be updated.

---

## 3. Network & Transport Security

| Item | Status | Notes |
|------|--------|-------|
| HTTPS | ✅ Enforced | Firebase Hosting serves exclusively over HTTPS; HTTP is auto-redirected |
| Firebase SDK over HTTPS | ✅ Default | All Realtime Database connections use WSS (WebSocket Secure) |
| IAP (Identity-Aware Proxy) | ❌ Not present | Firebase Hosting does not support Google Cloud IAP — anyone can load the login page |
| CORS | ✅ Not applicable | No custom backend; Firebase SDK handles auth and data directly |

**Risk:** Without IAP, the app's login page is publicly accessible. A bad actor can reach the sign-in screen. This is mitigated by Google OAuth + admin approval flow, but differs from the Cloud Run deployment where IAP blocks the request before the app loads.

**Recommendation:** If regulatory or enterprise policy requires infrastructure-level access control, map a custom domain to the existing Cloud Run + IAP deployment instead of using Firebase Hosting as the primary URL.

---

## 4. Firebase API Key Exposure

Firebase config (API key, project ID, etc.) is embedded in the client-side JavaScript bundle — this is **expected and normal** for Firebase web apps. The API key is not a secret; it identifies the project. Access is controlled by:
- Firebase Auth (must sign in)
- Firebase Database security rules (enforced server-side)

**Action required:** Restrict the Firebase API key in Google Cloud Console → APIs & Services → Credentials → API key restrictions → set allowed HTTP referrers to `deployment-portal-instrumental.web.app/*` only. This prevents the key from being used from other domains.

---

## 5. Input Validation & XSS

| Item | Status | Notes |
|------|--------|-------|
| `dangerouslySetInnerHTML` | ✅ Not used | No raw HTML injection anywhere in App.jsx |
| User-supplied text rendered as text nodes | ✅ Safe | React escapes all string values by default |
| URL fields (links in milestones) | ⚠️ Review | Link URLs entered by admins are rendered as `<a href>` — confirm no `javascript:` protocol is possible |

**Recommendation:** Add a check when saving milestone links to ensure the URL starts with `https://` or `http://`. This prevents `javascript:` URLs being stored.

---

## 6. Data Integrity

| Item | Status | Notes |
|------|--------|-------|
| Schema validation on `users/` | ✅ Partial | DB rules require `id, name, email, role, partyId` fields |
| Schema validation on `docData/` | ❌ None | No server-side validation on document structure — any shape of data can be written by admins |
| No audit log | ⚠️ Gap | There is no record of who changed what data or when |

**Recommendation:** Consider enabling Firebase Realtime Database export/backup (available in Firebase Console → Realtime Database → Backups) to have point-in-time recovery if data is accidentally corrupted.

---

## 7. Account & Session Management

| Item | Status | Notes |
|------|--------|-------|
| Session persistence | ✅ Firebase default | Sessions persist until the user signs out or token expires (~1 hour, auto-refreshed) |
| Sign out | ✅ Available | Sign-out button present in the UI |
| Token revocation | ⚠️ Not implemented | If a user's role is changed or account deleted in Firebase, their active session may persist until token refresh |

**Recommendation:** If you remove a user's access, also disable their account in Firebase Console → Authentication → Users to immediately invalidate their session.

---

## 8. Summary of Risks (Priority Order)

| Priority | Issue | Recommendation |
|----------|-------|---------------|
| 🔴 High | All approved users can read ALL project data | Add per-project read rules if different customers share the portal |
| 🟡 Medium | No IAP on Firebase Hosting URL | Use Cloud Run + IAP as primary if infrastructure-level blocking is required |
| 🟡 Medium | Firebase API key unrestricted | Restrict to `deployment-portal-instrumental.web.app` in Cloud Console |
| 🟡 Medium | No audit log | Enable Firebase backups; consider logging writes via Cloud Functions |
| 🟢 Low | Milestone link URLs not validated | Add `https://` prefix validation before saving |
| 🟢 Low | Pending user notifications | Ensure admins are alerted when a new user requests access |

---

## 9. Out of Scope

- Penetration testing / dynamic analysis
- Google Cloud project IAM permissions (who has access to the Firebase Console / Cloud Run service)
- Supply chain security (npm dependency audit — run `npm audit` separately)
